-- Run this SQL in Supabase SQL Editor.
create table if not exists public.user_library (
  user_id uuid primary key references auth.users(id) on delete cascade,
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.user_library enable row level security;
drop policy if exists "Users can read their own library" on public.user_library;
create policy "Users can read their own library"
on public.user_library for select
using (auth.uid() = user_id);
drop policy if exists "Users can insert their own library" on public.user_library;
create policy "Users can insert their own library"
on public.user_library for insert
with check (auth.uid() = user_id);
drop policy if exists "Users can update their own library" on public.user_library;
create policy "Users can update their own library"
on public.user_library for update
using (auth.uid() = user_id)
with check (auth.uid() = user_id);
