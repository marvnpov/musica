package com.sonora.music

import android.content.Intent
import android.os.Build
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin

@CapacitorPlugin(name = "SonoraPlayer")
class SonoraPlayerPlugin : Plugin() {
    private fun command(action: String, call: PluginCall, extras: (Intent.() -> Unit)? = null) {
        val intent = Intent(context, SonoraPlaybackService::class.java).setAction(action)
        extras?.invoke(intent)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && action == "SONORA_PLAY") {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
        call.resolve()
    }

    @PluginMethod
    fun play(call: PluginCall) = command("SONORA_PLAY", call) {
        putExtra("url", call.getString("url"))
        putExtra("title", call.getString("title"))
        putExtra("artist", call.getString("artist"))
        putExtra("artwork", call.getString("artwork"))
    }

    @PluginMethod fun pause(call: PluginCall) = command("SONORA_PAUSE", call)
    @PluginMethod fun resume(call: PluginCall) = command("SONORA_RESUME", call)
    @PluginMethod fun stop(call: PluginCall) = command("SONORA_STOP", call)
    @PluginMethod fun seek(call: PluginCall) = command("SONORA_SEEK", call) {
        putExtra("position", call.getLong("position", 0L))
    }
    @PluginMethod fun setVolume(call: PluginCall) = command("SONORA_VOLUME", call) {
        putExtra("volume", call.getFloat("volume", 1f))
    }
}
