package com.sonora.music

import android.app.PendingIntent
import android.content.Intent
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

class SonoraPlaybackService : MediaSessionService() {
    private var player: ExoPlayer? = null
    private var mediaSession: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val exo = ExoPlayer.Builder(this).build()
        player = exo
        mediaSession = MediaSession.Builder(this, exo).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "SONORA_PLAY" -> {
                val url = intent.getStringExtra("url")
                val title = intent.getStringExtra("title") ?: "Sonora"
                val artist = intent.getStringExtra("artist") ?: "Unknown artist"
                val artwork = intent.getStringExtra("artwork")
                if (!url.isNullOrBlank()) {
                    val metadata = MediaMetadata.Builder()
                        .setTitle(title)
                        .setArtist(artist)
                        .apply { if (!artwork.isNullOrBlank()) setArtworkUri(android.net.Uri.parse(artwork)) }
                        .build()
                    val item = MediaItem.Builder().setUri(url).setMediaMetadata(metadata).build()
                    player?.setMediaItem(item)
                    player?.prepare()
                    player?.play()
                }
            }
            "SONORA_PAUSE" -> player?.pause()
            "SONORA_RESUME" -> player?.play()
            "SONORA_STOP" -> player?.stop()
            "SONORA_SEEK" -> player?.seekTo(intent.getLongExtra("position", 0L))
            "SONORA_VOLUME" -> player?.volume = intent.getFloatExtra("volume", 1f).coerceIn(0f,1f)
        }
        return super.onStartCommand(intent, flags, startId)
    }

    override fun onDestroy() {
        mediaSession?.run {
            player.release()
            release()
        }
        mediaSession = null
        player = null
        super.onDestroy()
    }
}
