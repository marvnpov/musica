# Native Android Media3 playback integration

These files are the native source layer for background playback. Generate the Capacitor Android project first (`npx cap add android`), then merge the snippets/files into the generated project as described below.

## 1. Add Media3 dependencies

In `android/app/build.gradle` inside `dependencies` add:

```gradle
implementation "androidx.media3:media3-exoplayer:1.6.1"
implementation "androidx.media3:media3-session:1.6.1"
implementation "androidx.media3:media3-ui:1.6.1"
```

Use one consistent Media3 version for all Media3 artifacts.

## 2. Add manifest permissions and service

Merge the following into the generated `android/app/src/main/AndroidManifest.xml`:

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />
```

Inside `<application>` add:

```xml
<service
    android:name="com.sonora.music.SonoraPlaybackService"
    android:exported="true"
    android:foregroundServiceType="mediaPlayback">
    <intent-filter>
        <action android:name="androidx.media3.session.MediaSessionService" />
    </intent-filter>
</service>
```

## 3. Copy Kotlin sources

Copy `SonoraPlaybackService.kt` and `SonoraPlayerPlugin.kt` into the generated app's matching package directory:
`android/app/src/main/java/com/sonora/music/`.

If your generated app uses a different package, update the `package` declaration and service class name consistently.

## 4. Register the plugin

In the generated `MainActivity.kt`, register the plugin before `super.onCreate`:

```kotlin
import com.sonora.music.SonoraPlayerPlugin

override fun onCreate(savedInstanceState: Bundle?) {
    registerPlugin(SonoraPlayerPlugin::class.java)
    super.onCreate(savedInstanceState)
}
```

Keep the existing package declaration and other MainActivity code.

## 5. Rebuild and test

```bash
npm run build
npx cap sync android
npx cap open android
```

Test play, pause, next and stop on a physical Android device. Android background execution and notification behavior vary by Android version and manufacturer. Add a proper app icon and notification artwork before release.

The JS bridge automatically falls back to the HTML audio player in a browser. Native playback is used when the SonoraPlayer plugin is present.
