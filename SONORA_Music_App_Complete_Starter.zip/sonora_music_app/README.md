# SONORA — Music Player Starter (Web + Android)

Sonora is an original Apple-Music-inspired music player prototype with Audius catalogue integration, optional Jamendo search, local audio import, favourites, playlists, queue controls and a responsive web interface.

## Included
- Responsive dark interface for desktop and mobile browsers
- Listen Now, Browse, Search, Songs, Playlists, Local Files and Settings pages
- Audius trending and search integration
- Optional Jamendo search with your own Jamendo Client ID
- Track artwork, artist names and provider information
- Playback controls: play/pause, previous/next, seek, volume, shuffle and repeat
- Queue modal
- Favourites and recently played list stored in browser local storage
- Create playlists and add catalogue tracks
- Import audio files from your device (local browser session only)
- Capacitor configuration for Android packaging
- Optional Supabase email/password authentication and library sync
- SQL schema with row-level security policies
- Android Media3 foreground playback service and Capacitor bridge source

## Music rights and provider notes

A free API does not mean unrestricted rights to every recording.

- **Audius:** uses its public developer API for catalogue search, trending and stream URLs. Availability and permitted use are governed by Audius' current developer terms and the rights granted by individual uploaders.
- **Jamendo:** optional integration uses the official Jamendo API. Obtain a Client ID from its developer portal and comply with the API terms and each track's displayed Creative Commons licence. Some licences require attribution, prohibit commercial use, or restrict derivatives.
- **Internet Archive:** not wired into this prototype because Archive items have mixed rights. A production integration should only surface items with verified rights metadata and link to each item's rights statement.
- **Personal files:** files selected through Local Files are played locally by the browser; this prototype does not upload them.

Review current provider terms before publishing or monetizing the app.

## Requirements
- Node.js 20 LTS or newer
- npm
- For Android packaging: Android Studio, Android SDK and a compatible JDK (Android Studio's bundled JDK is recommended)

## Run the web app
1. Extract the ZIP.
2. Open a terminal in the `sonora_music_app` folder.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open the local URL printed by Vite (usually `http://localhost:5173`).

Production build:
```bash
npm run build
npm run preview
```
Production files are generated in `dist/`.

## Enable Jamendo (optional)
1. Register at https://developer.jamendo.com/.
2. Create an application and obtain a Client ID.
3. Open Sonora → Settings.
4. Paste the Client ID and save.
5. Search again to merge Jamendo results with Audius results.

The Client ID is stored in local browser storage in this prototype. For a public release, consider proxying requests through a backend if required by provider terms or operational security.

## Create the Android project
This ZIP contains the web app and Capacitor setup. Generate the native Android Studio project on your machine:

```bash
npm install
npx cap add android
npm run android:sync
npm run android:open
```

Wait for Gradle sync in Android Studio, select an emulator or connected Android device, then press Run.

For later web changes:
```bash
npm run android:sync
```
Then rebuild/run from Android Studio.

## Prototype limitations
This is a working starter, not a finished commercial streaming service.

- Android native background playback, lock-screen controls, Android Auto and media notifications need a native Media3 service integration. The current Capacitor wrapper does not implement that service.
- User accounts and cloud sync are not connected. Favourites, playlists and history are stored on the current browser/device.
- Jamendo search depends on a valid Client ID and current API/CORS availability.
- Audius stream availability depends on the provider and uploader settings.
- Offline downloads, synced lyrics, equalizer, cross-device queue sync, subscriptions and analytics are not implemented.
- Local file imports use browser object URLs and may need to be reselected after a reload. Persistent Android media indexing is a later task.

## Project structure
```text
sonora_music_app/
├── index.html
├── package.json
├── capacitor.config.json
├── README.md
├── public/
└── src/
    ├── main.js
    └── style.css
```

## Official references
- Audius developer documentation: https://docs.audius.co/
- Audius stream endpoint guide: https://docs.audius.co/developers/api/stream-url/
- Jamendo developer portal: https://developer.jamendo.com/
- Jamendo API terms: https://devportal.jamendo.com/api_terms_of_use
- Capacitor documentation: https://capacitorjs.com/docs


## Enable accounts and cloud sync (optional)

1. Create a free Supabase project at https://supabase.com/.
2. In Project Settings → API, copy the Project URL and the publishable key (or legacy anon key). Never use the `service_role` key in the app.
3. Open the Supabase SQL Editor and run `supabase-schema.sql`.
4. Run `npm install` again after adding the Supabase dependency.
5. Open Sonora → Settings → Account & cloud sync. Paste the URL/key, enter an email/password, then create an account or sign in.
6. Use **Sync my library now** to upload/download liked songs, playlists and listening history.

This first sync implementation is manual (not realtime). The remote library payload is one JSON document per user. Production applications should add conflict resolution, migrations, backup/export and automated tests.

## Android background playback (native Media3)

The `android-native/` folder contains a Media3 foreground playback service and a Capacitor plugin bridge. It is source code to merge after generating the Android project, not a prebuilt APK.

Follow `android-native/README.md` exactly. It describes dependencies, manifest declarations, plugin registration and rebuild steps. The app uses the native player bridge for catalogue tracks on Android and the HTML audio element in browsers. Native local-file URI support and full media-session queue/skip metadata are follow-up work.

## Updated limitations

- The native Media3 service source is included but must be integrated and built in Android Studio on a machine with the Android SDK. It has not been compiled against your local Android toolchain.
- Cloud sync requires you to create and configure your own free Supabase project and execute the SQL schema.
- The cloud sync action is manual and currently replaces the local library with the remote snapshot before uploading; it is not a multi-device conflict-resolution system.
- Native media notification artwork and lock-screen metadata depend on Android media-session integration and device behavior; test on a physical device.
