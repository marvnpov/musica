import { registerPlugin } from "@capacitor/core";
import { configureCloud, signUp, signIn, signOut, getSession, saveLibrary, loadLibrary } from "./cloud.js";
const NativePlayer = registerPlugin("SonoraPlayer");
const API = "https://api.audius.co/v1";
const APP_NAME = "sonora_music";
const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const audio = $("#audio");
let tracks = [], queue = [], queueIndex = -1, currentTrack = null, isShuffle = false, repeatMode = 0;
let localTracks = [], objectUrls = new Map(), activeLibrary = "liked";
let liked = JSON.parse(localStorage.getItem("sonora_liked") || "[]");
let recent = JSON.parse(localStorage.getItem("sonora_recent") || "[]");
let playlists = JSON.parse(localStorage.getItem("sonora_playlists") || "[]");
let jamendoId = localStorage.getItem("sonora_jamendo_id") || "";
let supabaseUrl = localStorage.getItem("sonora_supabase_url") || "";
let supabaseKey = localStorage.getItem("sonora_supabase_key") || "";
let nativeMode = false;
try { nativeMode = !!(window.Capacitor?.isNativePlatform?.()); } catch {}
let lastPage = "home";

function toast(msg){const el=$("#toast");el.textContent=msg;el.classList.add("show");clearTimeout(toast.t);toast.t=setTimeout(()=>el.classList.remove("show"),2400)}
function escapeHtml(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function fmt(n){if(!Number.isFinite(n))return "0:00";return `${Math.floor(n/60)}:${String(Math.floor(n%60)).padStart(2,"0")}`}
function persist(){localStorage.setItem("sonora_liked",JSON.stringify(liked));localStorage.setItem("sonora_recent",JSON.stringify(recent));localStorage.setItem("sonora_playlists",JSON.stringify(playlists))}
function trackId(t){return String(t.id ?? t.localId ?? t.title)}
function isLiked(t){return liked.some(x=>trackId(x)===trackId(t))}
function normalize(t){return {id:t.id,title:t.title||"Untitled track",artist:t.user?.name||t.artist||"Unknown artist",artwork:t.artwork?.["480x480"]||t.artwork?.["150x150"]||t.artwork||"",duration:t.duration||0,source:"Audius",permalink:t.permalink||"",license:t.license||"See provider track page",streamUrl:t.streamUrl||"",raw:t}}
function art(t,cls=""){return t.artwork?`<img class="${cls}" src="${escapeHtml(t.artwork)}" alt="" loading="lazy" onerror="this.style.display='none'">`:`<div class="cover-fallback ${cls}">♫</div>`}
async function api(path){const r=await fetch(`${API}${path}${path.includes("?")?"&":"?"}app_name=${APP_NAME}`);if(!r.ok)throw new Error(`Audius request failed (${r.status})`);return r.json()}
async function searchAudius(q,limit=20){const data=await api(`/tracks/search?query=${encodeURIComponent(q)}&limit=${limit}`);return (data.data||[]).map(normalize)}
async function searchJamendo(q,limit=12){
  if(!jamendoId)return [];
  const url=`https://api.jamendo.com/v3.0/tracks/?client_id=${encodeURIComponent(jamendoId)}&format=json&limit=${limit}&namesearch=${encodeURIComponent(q)}&audioformat=mp32`;
  const r=await fetch(url);if(!r.ok)throw new Error("Jamendo unavailable");
  const data=await r.json();
  return (data.results||[]).filter(t=>t.audio).map(t=>({id:`jamendo-${t.id}`,title:t.name||"Untitled track",artist:t.artist_name||"Unknown artist",artwork:t.album_image||t.image||"",duration:t.duration||0,source:"Jamendo",permalink:t.shareurl||"",license:t.license_ccurl||"Check the Jamendo track page for its licence",streamUrl:t.audio,raw:t}));
}
async function trending(){const data=await api("/tracks/trending?limit=12");return (data.data||[]).map(normalize)}
function streamUrl(t){return t.streamUrl||`${API}/tracks/${encodeURIComponent(t.id)}/stream?app_name=${APP_NAME}`}
function showPage(name){lastPage=name;$$(".page").forEach(p=>p.classList.toggle("active-page",p.id===`page-${name}`));$$("[data-page]").forEach(b=>b.classList.toggle("active",b.dataset.page===name));if(name==="library")renderLibrary();if(name==="playlists")renderPlaylists();if(name==="local")renderLocal()}
function cover(t){return t.artwork||""}
function card(t){return `<article class="track-card" data-play-id="${escapeHtml(trackId(t))}"><div class="cover-wrap">${art(t)}<button class="cover-play" aria-label="Play">▶</button></div><b>${escapeHtml(t.title)}</b><small>${escapeHtml(t.artist)}</small></article>`}
function row(t,i){return `<div class="track-row"><img class="row-cover" src="${escapeHtml(cover(t))}" onerror="this.style.opacity=.15" alt=""><div class="row-meta"><b>${escapeHtml(t.title)}</b><small>${escapeHtml(t.artist)} · ${escapeHtml(t.source||"Audius")}</small></div><span class="row-duration">${fmt(t.duration)}</span><div class="row-actions"><button data-play-row="${i}" title="Play">▶</button><button data-like="${escapeHtml(trackId(t))}" title="Like" class="${isLiked(t)?"liked":""}">${isLiked(t)?"♥":"♡"}</button><button data-add="${escapeHtml(trackId(t))}" title="Add to playlist">＋</button></div></div>`}
function bindPlay(container,list){container.querySelectorAll("[data-play-id]").forEach(el=>el.addEventListener("click",()=>{const t=list.find(x=>trackId(x)===el.dataset.playId);if(t)playTrack(t,list)}));container.querySelectorAll("[data-play-row]").forEach(el=>el.addEventListener("click",()=>playTrack(list[Number(el.dataset.playRow)],list)));container.querySelectorAll("[data-like]").forEach(el=>el.addEventListener("click",()=>{const t=list.find(x=>trackId(x)===el.dataset.like);if(t)toggleLike(t);renderCurrentPage()}));container.querySelectorAll("[data-add]").forEach(el=>el.addEventListener("click",()=>{const t=list.find(x=>trackId(x)===el.dataset.add);if(t)addToPlaylist(t)}))}
function renderCards(el,list){el.innerHTML=list.length?list.map(card).join(""):`<div class="empty-state">No tracks to show yet.</div>`;bindPlay(el,list)}
function renderRows(el,list){el.innerHTML=list.length?list.map(row).join(""):`<div class="empty-state">Nothing here yet. Search for music or save a track you love.</div>`;bindPlay(el,list)}
function renderCurrentPage(){const page=$(".active-page")?.id;if(page==="page-library")renderLibrary();if(page==="page-local")renderLocal();if(page==="page-playlists")renderPlaylists();if(currentTrack)updatePlayer()}
async function loadTrending(){const grid=$("#trendingGrid"),list=$("#browseTracks");grid.innerHTML=`<div class="loading-state">Loading tracks<span class="loader"></span></div>`;try{tracks=await trending();renderCards(grid,tracks.slice(0,8));renderRows(list,tracks); }catch(e){grid.innerHTML=`<div class="empty-state">Couldn't reach Audius. Check your connection and refresh.</div>`;list.innerHTML="";console.error(e)}}
async function runSearch(q){
  if(!q.trim())return;
  $("#searchTitle").textContent=`Results for “${q}”`;
  $("#searchEyebrow").textContent="MUSIC CATALOGUES";
  $("#searchHint").textContent="Searching available providers…";
  $("#searchResults").innerHTML=`<div class="loading-state">Searching<span class="loader"></span></div>`;
  const results=await Promise.allSettled([searchAudius(q,24),searchJamendo(q,12)]);
  const list=results.flatMap(r=>r.status==="fulfilled"?r.value:[]);
  $("#searchHint").textContent=`${list.length} tracks found. Select a track to start listening.`;
  renderRows($("#searchResults"),list);
}

function playTrack(t,list=tracks){if(!t)return;currentTrack=t;queue=list.length?list:[t];queueIndex=Math.max(0,queue.findIndex(x=>trackId(x)===trackId(t)));const url=t.localUrl||streamUrl(t);
  if(nativeMode && !t.localUrl){
    NativePlayer.play({url,title:t.title,artist:t.artist,artwork:t.artwork||""}).then(()=>{toast("Playing on Android");$("#playBtn").textContent="Ⅱ"}).catch(e=>{console.error(e);toast("Native playback error. Check Android setup.")});
  } else {
    audio.src=url;audio.play().then(()=>toast("Now playing")).catch(e=>{console.error(e);toast("Playback unavailable for this track. Try another one.")});
  }recent=[t,...recent.filter(x=>trackId(x)!==trackId(t))].slice(0,50);persist();updatePlayer();renderCurrentPage()}
function updatePlayer(){if(!currentTrack)return;$("#nowTitle").textContent=currentTrack.title;$("#nowArtist").textContent=currentTrack.artist;$("#nowArt").innerHTML=currentTrack.artwork?`<img src="${escapeHtml(currentTrack.artwork)}" alt="">`:"♫";$("#playerLike").textContent=isLiked(currentTrack)?"♥":"♡";$("#playerLike").classList.toggle("liked",isLiked(currentTrack))}
function toggleLike(t){if(isLiked(t))liked=liked.filter(x=>trackId(x)!==trackId(t));else liked.unshift(t);persist();renderCurrentPage();updatePlayer();toast(isLiked(t)?"Added to favourites":"Removed from favourites")}
function next(){if(!queue.length)return;queueIndex=isShuffle?Math.floor(Math.random()*queue.length):(queueIndex+1)%queue.length;playTrack(queue[queueIndex],queue)}
function prev(){if(audio.currentTime>3){audio.currentTime=0;return}queueIndex=(queueIndex-1+queue.length)%queue.length;playTrack(queue[queueIndex],queue)}
function renderLibrary(){const list=activeLibrary==="liked"?liked:recent;renderRows($("#libraryTracks"),list);$$("[data-library]").forEach(b=>b.classList.toggle("active",b.dataset.library===activeLibrary))}
function renderLocal(){renderRows($("#localTracks"),localTracks)}
function renderPlaylists(){const el=$("#playlistGrid");el.innerHTML=playlists.length?playlists.map((p,i)=>`<div class="playlist-tile" data-playlist="${i}"><div class="playlist-art">♫</div><b>${escapeHtml(p.name)}</b><small>${p.tracks.length} tracks</small></div>`).join(""):`<div class="empty-state">Your playlists will appear here.</div>`;el.querySelectorAll("[data-playlist]").forEach(tile=>tile.addEventListener("click",()=>{const p=playlists[Number(tile.dataset.playlist)];openModal(`<h2>${escapeHtml(p.name)}</h2><p class="page-subtitle">${p.tracks.length} saved tracks</p>${p.tracks.map((t,i)=>`<div class="queue-item"><img src="${escapeHtml(t.artwork||"")}" onerror="this.style.opacity=.1"><div><b>${escapeHtml(t.title)}</b><small>${escapeHtml(t.artist)}</small></div><button class="row-actions" data-play-pl="${i}">▶</button></div>`).join("")||"<p>No tracks yet. Add tracks from search results.</p>"}`);$("#modalContent").querySelectorAll("[data-play-pl]").forEach(b=>b.onclick=()=>playTrack(p.tracks[Number(b.dataset.playPl)],p.tracks))}))}
function openModal(html){$("#modalContent").innerHTML=html;$("#modalBackdrop").classList.add("open")}
function closeModal(){$("#modalBackdrop").classList.remove("open")}
function addToPlaylist(t){if(!playlists.length){toast("Create a playlist first");return}openModal(`<h2>Add to playlist</h2>${playlists.map((p,i)=>`<button class="playlist-choice" data-add-playlist="${i}">${escapeHtml(p.name)} →</button>`).join("")}`);$$("[data-add-playlist]").forEach(b=>b.onclick=()=>{const p=playlists[Number(b.dataset.addPlaylist)];if(!p.tracks.some(x=>trackId(x)===trackId(t)))p.tracks.push(t);persist();closeModal();toast("Added to "+p.name)})}
function renderGenres(){const genres=[["Afrobeats","#633e49"],["Electronic","#344d61"],["Hip-hop","#624a35"],["Jazz","#36564e"],["Ambient","#4e4566"],["Indie","#6a4b55"],["House","#69513d"],["Soul","#475e58"]];$("#genreGrid").innerHTML=genres.map(([g,c])=>`<button class="genre-card" style="background:linear-gradient(130deg,${c},#242424)" data-genre="${g}">${g}<small>Explore the sound ↗</small></button>`).join("");$$("[data-genre]").forEach(b=>b.onclick=()=>{showPage("search");$("#searchInput").value=b.dataset.genre;runSearch(b.dataset.genre)})}
function openQueue(){openModal(`<h2>Up next</h2><p class="page-subtitle">${queue.length} tracks in your queue</p>${queue.map((t,i)=>`<div class="queue-item"><img src="${escapeHtml(t.artwork||"")}" onerror="this.style.opacity=.1"><div style="flex:1"><b>${escapeHtml(t.title)}</b><small>${escapeHtml(t.artist)}</small></div><button data-queue-play="${i}">▶</button></div>`).join("")||"<p>Your queue is empty.</p>"}`);$$("[data-queue-play]").forEach(b=>b.onclick=()=>playTrack(queue[Number(b.dataset.queuePlay)],queue))}
function init(){loadTrending();renderGenres();$("#jamendoId").value=jamendoId;$("#supabaseUrl").value=supabaseUrl;$("#supabaseKey").value=supabaseKey;
  if(supabaseUrl&&supabaseKey){try{configureCloud(supabaseUrl,supabaseKey);getSession().then(s=>$("#accountStatus").textContent=s?.user?`Signed in as ${s.user.email}`:"Configured · not signed in").catch(()=>{});}catch{}}
  const setupCloud=()=>{supabaseUrl=$("#supabaseUrl").value.trim();supabaseKey=$("#supabaseKey").value.trim();localStorage.setItem("sonora_supabase_url",supabaseUrl);localStorage.setItem("sonora_supabase_key",supabaseKey);configureCloud(supabaseUrl,supabaseKey);};
  $("#signUpBtn").onclick=async()=>{try{setupCloud();const r=await signUp($("#accountEmail").value.trim(),$("#accountPassword").value);$("#accountStatus").textContent=r.session?`Signed in as ${r.user.email}`:"Check your email to confirm your account.";toast("Account request completed");}catch(e){$("#accountStatus").textContent=e.message;toast("Account setup failed")}};
  $("#signInBtn").onclick=async()=>{try{setupCloud();const r=await signIn($("#accountEmail").value.trim(),$("#accountPassword").value);$("#accountStatus").textContent=`Signed in as ${r.user.email}`;toast("Signed in");}catch(e){$("#accountStatus").textContent=e.message;toast("Sign-in failed")}};
  $("#signOutBtn").onclick=async()=>{try{setupCloud();await signOut();$("#accountStatus").textContent="Signed out.";toast("Signed out");}catch(e){$("#accountStatus").textContent=e.message}};
  $("#syncNowBtn").onclick=async()=>{try{setupCloud();const remote=await loadLibrary();if(remote){liked=remote.liked||liked;recent=remote.recent||recent;playlists=remote.playlists||playlists;persist();renderCurrentPage();}await saveLibrary({liked,recent,playlists,syncedAt:new Date().toISOString()});$("#accountStatus").textContent="Library synchronized.";toast("Cloud sync complete");}catch(e){$("#accountStatus").textContent=e.message;toast("Sync failed")}};
  $$("[data-page]").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.page)));
  $$("[data-goto]").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.goto)));
  $("#discoverBtn").onclick=()=>showPage("browse");
  $("#searchForm").onsubmit=e=>{e.preventDefault();runSearch($("#searchInput").value)};
  $$("[data-search]").forEach(b=>b.onclick=()=>{$("#searchInput").value=b.dataset.search;runSearch(b.dataset.search)});
  $$(".mood-card").forEach(b=>b.onclick=()=>{showPage("search");$("#searchInput").value=b.dataset.query;runSearch(b.dataset.query)});
  $("#refreshTrending").onclick=loadTrending;
  $$("[data-library]").forEach(b=>b.onclick=()=>{activeLibrary=b.dataset.library;renderLibrary()});
  $("#createPlaylist").onclick=()=>{openModal(`<h2>Create a playlist</h2><p class="page-subtitle">Give your collection a name.</p><input id="playlistName" placeholder="e.g. Late night sounds" maxlength="40"><button class="primary-button" id="confirmPlaylist">Create playlist</button>`);$("#confirmPlaylist").onclick=()=>{const name=$("#playlistName").value.trim();if(!name)return toast("Enter a playlist name");playlists.push({name,tracks:[]});persist();closeModal();renderPlaylists();toast("Playlist created")}};
  $("#fileInput").onchange=e=>{for(const f of [...e.target.files]){const url=URL.createObjectURL(f),t={localId:`local-${Date.now()}-${Math.random()}`,title:f.name.replace(/\.[^.]+$/,""),artist:"On this device",duration:0,artwork:"",source:"Local file",localUrl:url};localTracks.push(t);objectUrls.set(t.localId,url)}renderLocal();toast(`${e.target.files.length} file(s) added`)};
  $("#playBtn").onclick=()=>{if(!currentTrack){if(tracks[0])playTrack(tracks[0],tracks);return}if(nativeMode && !currentTrack.localUrl){const method=$("#playBtn").textContent==="Ⅱ"?"pause":"resume";NativePlayer[method]().then(()=>{$("#playBtn").textContent=method==="pause"?"▶":"Ⅱ"}).catch(()=>toast("Player command failed"));}else if(audio.paused)audio.play().catch(()=>toast("Playback unavailable"));else audio.pause()};
  audio.onplay=()=>$("#playBtn").textContent="Ⅱ";audio.onpause=()=>$("#playBtn").textContent="▶";
  $("#nextBtn").onclick=next;$("#prevBtn").onclick=prev;audio.onended=()=>{if(repeatMode===2){audio.currentTime=0;audio.play()}else if(queueIndex<queue.length-1||repeatMode===1)next()};
  $("#shuffleBtn").onclick=()=>{isShuffle=!isShuffle;$("#shuffleBtn").classList.toggle("active",isShuffle);toast(isShuffle?"Shuffle on":"Shuffle off")};
  $("#repeatBtn").onclick=()=>{repeatMode=(repeatMode+1)%3;$("#repeatBtn").classList.toggle("active",repeatMode>0);$("#repeatBtn").textContent=repeatMode===2?"↻¹":"↻";toast(["Repeat off","Repeat all","Repeat one"][repeatMode])};
  audio.ontimeupdate=()=>{if(audio.duration){$("#seekBar").value=audio.currentTime/audio.duration*1000;$("#currentTime").textContent=fmt(audio.currentTime);$("#duration").textContent=fmt(audio.duration)}};
  $("#seekBar").oninput=()=>{if(audio.duration)audio.currentTime=Number($("#seekBar").value)/1000*audio.duration;if(nativeMode)NativePlayer.seek({position:Math.round(Number($("#seekBar").value)/1000*(currentTrack?.duration||0)*1000)}).catch(()=>{});};
  $("#volumeBar").oninput=()=>{const v=Number($("#volumeBar").value);audio.volume=v;if(nativeMode)NativePlayer.setVolume({volume:v}).catch(()=>{});};
  $("#playerLike").onclick=()=>currentTrack&&toggleLike(currentTrack);
  $("#queueBtn").onclick=openQueue;$("#settingsBtn").onclick=()=>showPage("settings");
  $("#saveSettings").onclick=()=>{jamendoId=$("#jamendoId").value.trim();localStorage.setItem("sonora_jamendo_id",jamendoId);toast("Settings saved")};
  $("#modalClose").onclick=closeModal;$("#modalBackdrop").onclick=e=>{if(e.target.id==="modalBackdrop")closeModal()};
  $("#backBtn").onclick=()=>showPage("home");$("#forwardBtn").onclick=()=>showPage("browse");
  audio.volume=.8;
}
init();
