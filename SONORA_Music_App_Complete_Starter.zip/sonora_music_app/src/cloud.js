import { createClient } from "@supabase/supabase-js";

let client = null;
let currentUser = null;

export function configureCloud(url, key) {
  if (!url || !key) throw new Error("Enter your Supabase project URL and publishable/anon key.");
  client = createClient(url.trim(), key.trim(), {
    auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
  });
  return client;
}
export function cloudClient(){ return client; }
export async function signUp(email,password) {
  if(!client) throw new Error("Configure Supabase first.");
  const {data,error}=await client.auth.signUp({email,password});
  if(error) throw error;
  currentUser=data.user;
  return data;
}
export async function signIn(email,password) {
  if(!client) throw new Error("Configure Supabase first.");
  const {data,error}=await client.auth.signInWithPassword({email,password});
  if(error) throw error;
  currentUser=data.user;
  return data;
}
export async function signOut() {
  if(!client) return;
  const {error}=await client.auth.signOut();
  if(error) throw error;
  currentUser=null;
}
export async function getSession() {
  if(!client) return null;
  const {data,error}=await client.auth.getSession();
  if(error) throw error;
  currentUser=data.session?.user || null;
  return data.session;
}
export async function saveLibrary(payload) {
  if(!client) throw new Error("Configure Supabase first.");
  const session=await getSession();
  if(!session?.user) throw new Error("Sign in before syncing.");
  const {error}=await client.from("user_library").upsert({
    user_id: session.user.id,
    payload,
    updated_at: new Date().toISOString()
  },{onConflict:"user_id"});
  if(error) throw error;
}
export async function loadLibrary() {
  if(!client) throw new Error("Configure Supabase first.");
  const session=await getSession();
  if(!session?.user) throw new Error("Sign in before syncing.");
  const {data,error}=await client.from("user_library").select("payload").eq("user_id",session.user.id).maybeSingle();
  if(error) throw error;
  return data?.payload || null;
}
